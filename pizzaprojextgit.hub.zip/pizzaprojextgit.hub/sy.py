
import pandas as pd
import matplotlib.pyplot as plt
import  seaborn as sns

df = pd.read_csv(r"C:\Users\Lenovo\Desktop\pizza_sales_excel_file.csv", encoding="latin1")
print(df.describe())


plt.hist(df["pizza_id"], histtype='bar', ec='black')
plt.xlabel('pizza_id')
plt.ylabel('quantity')
plt.title('Distribution of pizza id')
plt.show()

df = pd.read_csv(r"C:\Users\lenovo\Downloads\Pokemon.csv", encoding="latin1")

# Check the first few rows of the DataFrame to ensure it's loaded correctly
print(df.head())
#Create scatter plot
sns.lmplot(x='unit_price', y='total_price', data=df)
#Show the plot
plt.show()



color_palette = sns.color_palette("husl", n_colors=len(df['quantity'].unique()))

sns.violinplot(x='quantity', y='order_id', data=df, hue='quantity', legend=False, palette=color_palette)
plt.show()


Labels
plt.xlabel('pizza_name')
plt.ylabel('quantity')
plt.title('Type of pizza by quantity')
plt.show()

